return [[
Have a nice sample text!
/newline/
;D
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
/newline/
Thanks for scrolling!
-im_tem
]]
